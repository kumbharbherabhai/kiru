# Shopsy Scraper

A modular Python-based scraper for extracting filter URLs, product IDs, and exporting results to CSV from the Shopsy mobile accessories category.

## Contents

- **config.py**: Database and collection configuration with date-based suffixes.
- **filter_url_generator.py**: Generates static and dynamic filter URLs and stores them in MongoDB.
- **product_id_scraper.py**: Fetches product listing pages in parallel, extracts product IDs, saves HTML, and inserts metadata into MongoDB.
- **export_to_csv.py**: Exports collected product records (ID, source URL, HTML path) to a CSV file.
- **main.py**: Orchestrates the three stages in sequence.

## Prerequisites

- Python 3.8+
- MongoDB Server running locally or accessible via `MONGO_URI`
- Required Python packages:
  ```bash
  pip install pymongo requests lxml jmespath
  ```

## Setup

1. Clone the repository or copy all `.py` files into a single directory.
2. Adjust `MONGO_URI` in `config.py` if your MongoDB instance differs.

## Usage

Run the entire pipeline via:

```bash
python main.py
```

This will:
1. Generate and insert filter URLs into MongoDB.
2. Scrape product listing pages, save HTML, and extract product IDs.
3. Export results to a CSV file named `product_list.csv`.

## Customization

- Change output directory in `product_id_scraper.py` by editing `OUTPUT_DIR`.
- Modify JMESPath queries in `JMESPATH_RULES` to target additional fields.
- Adjust thread pool size via `max_workers` in `run_scraper()`.

## License

MIT License. Feel free to modify and adapt for your own projects.
