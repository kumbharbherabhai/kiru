import os
import uuid
import json
import contextlib
import threading
import requests
from lxml import html
from jmespath import search
from concurrent.futures import ThreadPoolExecutor, as_completed
from pymongo import MongoClient
import config

OUTPUT_DIR = os.path.join('D:', os.sep, 'HTMLs', 'shopsy', 'IN', 'PL')
os.makedirs(OUTPUT_DIR, exist_ok=True)

# JMESPath queries for various containers
JMESPATH_RULES = [
    'props.pageProps.initialState.pageData.RESPONSE.slots[*].widget.data.renderableComponents[*].value.productId',
    'props.pageProps.initialState.pageData.RESPONSE.slots[*].widget.data.products[*].adInfo.productId',
    'props.pageProps.initialState.pageData.RESPONSE.slots[*].widget.data.products[*].addToWishlist.action.params.productId',
    'props.pageProps.initialState.pageData.RESPONSE.slots[*].widget.data.products[*].productInfo.action.params.productId',
]
lock = threading.Lock()


def _flatten_items(lst):
    res = []
    for elem in lst:
        if isinstance(elem, list):
            res.extend(_flatten_items(elem))
        else:
            res.append(elem)
    return res


def _process_endpoint(url):
    print(f"Starting scrape: {url}")
    page = 1
    client = MongoClient(config.MONGO_URI)
    db = client[config.DB_NAME]
    p_coll = db[config.PL_COLL]

    while True:
        page_url = f"{url}&page={page}"
        print(f"Fetching page {page}: {page_url}")
        try:
            response = requests.get(page_url, timeout=10)
            tree = html.fromstring(response.content)
            filename = f"{uuid.uuid4()}.html"
            file_path = os.path.join(OUTPUT_DIR, filename)
            with open(file_path, 'wb') as f:
                f.write(response.content)

            script = tree.xpath('//script[@id="__NEXT_DATA__" and @type="application/json"]/text()')
            if not script:
                print("No JSON container.")
                break

            data = json.loads(script[0])
            ids = set()
            for rule in JMESPATH_RULES:
                chunk = search(rule, data)
                if chunk:
                    ids.update(_flatten_items(chunk))

            if not ids:
                print("No product IDs found, terminating.")
                break

            inserted = 0
            with lock:
                for pid in ids:
                    with contextlib.suppress(Exception):
                        p_coll.insert_one({
                            'productId': pid,
                            'sourceUrl': page_url,
                            'htmlPath': file_path
                        })
                        inserted += 1
            print(f"Inserted {inserted} new IDs.")
            page += 1

        except Exception as err:
            print(f"Error at page {page}: {err}")
            break


def run_scraper():
    client = MongoClient(config.MONGO_URI)
    db = client[config.DB_NAME]
    sku_coll = db[config.SKU_COLL]
    urls = [doc['url'] for doc in sku_coll.find({}, {'url': 1})]

    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(_process_endpoint, u) for u in urls]
        for f in as_completed(futures):
            f.result()

if __name__ == '__main__':
    run_scraper()