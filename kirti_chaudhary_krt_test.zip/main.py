import filter_url_generator as url_gen
import product_id_scraper as scraper
import export_to_csv as exporter


def main():
    print('>>> Stage 1: Generate filter URLs')
    url_gen.add_filter_endpoints()

    print('\n>>> Stage 2: Scrape product IDs')
    scraper.run_scraper()

    print('\n>>> Stage 3: Export to CSV')
    exporter.dump_product_list()


if __name__ == '__main__':
    main()