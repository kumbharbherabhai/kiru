import csv
from pymongo import MongoClient
import config


def dump_product_list(output_path='product_list.csv'):
    """
    Connect to MongoDB and export product entries to a CSV.
    """
    client = MongoClient(config.MONGO_URI)
    db = client[config.DB_NAME]
    coll = db[config.PL_COLL]

    projection = { '_id': 0, 'productId': 1, 'sourceUrl': 1, 'htmlPath': 1 }
    cursor = coll.find({}, projection)

    with open(output_path, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['productId', 'sourceUrl', 'htmlPath'])
        for record in cursor:
            writer.writerow([
                record.get('productId', ''),
                record.get('sourceUrl', ''),
                record.get('htmlPath', '')
            ])

    print(f"CSV export completed: {output_path}")