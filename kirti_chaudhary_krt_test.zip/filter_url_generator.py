import json
import contextlib
import requests
from lxml import html
from pymongo import MongoClient
from jmespath import search
import config


def _flatten(items):
    result = []
    for entry in items or []:
        if isinstance(entry, list):
            result.extend(_flatten(entry))
        elif isinstance(entry, str):
            result.append(entry)
    return result


def add_filter_endpoints():
    """
    Insert static price-range and dynamic filter URLs into MongoDB,
    using JMESPath to extract all dynamic facet params.
    """
    client = MongoClient(config.MONGO_URI)
    db = client[config.DB_NAME]
    sku_coll = db[config.SKU_COLL]
    sku_coll.create_index('url', unique=True)

    # Static price buckets
    base = 'https://www.shopsy.in/mobile-accessories-online/pr'
    brackets = [100, 200, 300, 400, 500, 750, 1000]

    count_static = 0
    for i, low in enumerate(brackets):
        high = brackets[i + 1] if i + 1 < len(brackets) else 'Max'
        p_low  = f"facets.price_range.from%3D{low}"
        p_high = f"facets.price_range.to%3D{high}"
        url = f"{base}?p%5B%5D={p_low}&p%5B%5D={p_high}"
        with contextlib.suppress(Exception):
            sku_coll.insert_one({'url': url})
            count_static += 1
    print(f"[STATIC] URLs added: {count_static}")

    # Dynamic facets via JMESPath
    resp = requests.get('https://www.shopsy.in/mobile-accessories-online/')
    tree = html.fromstring(resp.content)
    script = tree.xpath('//script[@id="__NEXT_DATA__" and @type="application/json"]/text()')

    if not script:
        print("[DYNAMIC] No JSON script found.")
        return

    data = json.loads(script[0])

    # JMESPath expression to grab every "params" array under facetResponse.facets
    expr = (
        "props.pageProps.initialState.pageData.RESPONSE."
        "slots[*].widget.data.filters.facetResponse.facets[*]."
        "values[*].values[*].resource.params"
    )
    raw_params = search(expr, data)
    flat_params = _flatten(raw_params)

    count_dyn = 0
    prefix = 'https://www.shopsy.in/mobile-accessories-online/pr?p%5B%5D='
    for param in flat_params:
        url = prefix + param
        with contextlib.suppress(Exception):
            sku_coll.insert_one({'url': url})
            count_dyn += 1
    print(f"[DYNAMIC] URLs added: {count_dyn}")
