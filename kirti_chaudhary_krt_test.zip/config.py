from datetime import datetime

# Compose a timestamp-based suffix for database names
def _current_suffix():
    return datetime.now().strftime("%Y_%m_%d")

DB_PREFIX = 'shopsy'
MONGO_URI = 'mongodb://localhost:27017/'
DB_NAME = f"{DB_PREFIX}_{_current_suffix()}"
SKU_COLL = f"{DB_PREFIX}_insert_{_current_suffix()}"
PL_COLL  = f"{DB_PREFIX}_pid_{_current_suffix()}"